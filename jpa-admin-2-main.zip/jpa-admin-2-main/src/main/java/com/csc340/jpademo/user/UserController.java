
package com.csc340.jpademo.user;

/**
 *
 * @author chrisnieves
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping("/all")
    public String getUsers(Model model) {
        List<User> userList = userService.getAll();
        model.addAttribute("userList", userList);
        return "user/user-list"; // Assumes there is a user/user-list.html Thymeleaf template
    }

    @PutMapping("/edit-role/{user_id}")
    public String showEditUserRoleForm(@PathVariable("user_id") Long userId, Model model) {
        // Assuming userService.getUserById(userId) fetches the user information by ID
        User user = userService.getUserById(userId);
        model.addAttribute("user", user);
        return "user/edit-role"; // Assuming there is a user/edit-role.html Thymeleaf template
    }

    @PostMapping("/edit-role/{user_id}")
    public String editUserRole(@PathVariable("user_id") Long userId, @RequestParam String newRole, Model model) {
        userService.editUserRole(userId, newRole); // Update user role
        return "redirect:/user/all"; // Redirect back to user list
    }

    @DeleteMapping("/delete/{user_id}")
    public String deleteUser(@PathVariable("user_id") Long userId, Model model) {
        userService.deleteUser(userId);
        return "redirect:/user/all"; // Redirect back to the user list page
    }

    @GetMapping("/search")
    public String searchUsers(@RequestParam String keyword, Model model) {
        List<User> searchResults = userService.searchUsers(keyword);
        model.addAttribute("userList", searchResults);
        return "user/user-list"; // Render the user list page with search results
    }
}

