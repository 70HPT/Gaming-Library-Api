
package com.csc340.jpademo.user;

/**
 *
 * @author chrisnieves
 */

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    
    
     public List<User> getAll() {
        return userRepository.findAll();
    }
     public User getUserById(Long userId) {
        return userRepository.findById(userId).orElse(null);
    }

    public User editUserRole(Long user_Id, String newRole) {
        User admin = userRepository.findById(user_Id).orElse(null);
        if (admin != null) {
            admin.setRole(newRole);
            return userRepository.save(admin);
        }
        return null; // Or throw an exception as per your needs
    }

    public void deleteUser(Long user_Id) {
        userRepository.deleteById(user_Id);
    }

    public List<User> searchUsers(String keyword) {
        // Implement your search logic here, e.g., using adminRepository.findByUsernameContaining(keyword)
        return userRepository.findAll(); // Placeholder return for demonstration
    }
}
