# jpa-demo
## Demo WebApp using SpringBoot (MVC), MySQL, JPA and Hibernate, and ThymeLeaf.
- Clone the project and open it in NetBeans. Do not clean and build yet!
- Open XAMPP Control Panel Dashboard.
- Start Apache.
- Start MySQL.
- Click on MySQL Admin, to open the database dashboard on your browser.
- Create a database with the name 'crudapp'.
- Clean and Build the project.
- Run->Set Project Configuration->Customize->Run->Main Class->Browse->Select JpaDemoApplication .java.
- Run the main method.
- On Web Browser:
  * http://localhost:8080/goal/all
